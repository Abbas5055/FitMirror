# 🪞 FitMirror

**Single-photo virtual try-on + measurement-grounded size recommendation for Indian wear.**

> Upload one front-facing photo + a garment → get photoreal try-on, body measurements (cm),
> and an *explainable* size suggestion: *"You need M because chest 96 cm fits M range 94–98 cm."*

[![Python 3.10](https://img.shields.io/badge/python-3.10-blue)](https://python.org)
[![PyTorch](https://img.shields.io/badge/pytorch-2.1+-orange)](https://pytorch.org)
[![MediaPipe](https://img.shields.io/badge/mediapipe-0.10-green)](https://mediapipe.dev)
[![Streamlit](https://img.shields.io/badge/streamlit-1.32-red)](https://streamlit.io)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## What makes this different

Most try-on systems (VITON, TryOnDiffusion) warp garments in 2D — looks fake at angles, ignores body shape. FitMirror grounds the warp in **actual body geometry**:

1. **Monocular depth** (Depth Anything v2) → pseudo-3D body shape from a single photo
2. **SMPL parametric fit** → body measurements + canonical mesh
3. **Garment warp driven by SMPL surface**, not just 2D keypoints
4. **Size recommendation with cm-level reasoning** ← the business moat

---

## Pipeline

```
1 photo + garment image
 ├─ Background removal   (rembg)
 ├─ Pose estimation      (MediaPipe Pose, 33 landmarks)
 ├─ Monocular depth      (Depth Anything v2)
 ├─ SMPL fitting         (3-stage Adam: global → pose → shape)
 │   └─► chest / waist / hip / shoulder / height (cm)
 ├─ Garment parsing      (rembg + panel heuristics)
 ├─ TPS warp             (SMPL surface → garment control points)
 └─ Compositing          (Poisson blending)

Output: try-on PNG + measurements JSON + size recommendation + .glb avatar
```

See [`docs/architecture.md`](docs/architecture.md) for full design rationale.

---

## Setup

### 1. Clone & install dependencies

```bash
git clone https://github.com/Abbas5055/fitmirror.git
cd fitmirror
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Download SMPL model files (required for accurate measurements)

1. Register at https://smpl.is.tue.mpg.de/
2. Download **SMPL_python_v.1.1.0.zip**
3. Place the neutral model:

```
models/
└── smpl/
    └── SMPL_NEUTRAL.pkl
```

> Without SMPL files, the app falls back to heuristic measurements from MediaPipe landmarks.

### 3. Run the app

```bash
streamlit run app.py
```

---

## Project structure

```
fitmirror/
├── app.py                    # Streamlit 3-step wizard
├── fitmirror/
│   ├── body/
│   │   ├── pose.py           # MediaPipe wrapper + MP→SMPL keypoint map
│   │   ├── segment.py        # rembg background removal
│   │   ├── depth.py          # Depth Anything v2
│   │   ├── smpl_fit.py       # ★ core IP — 3-stage SMPL optimization
│   │   └── measure.py        # mesh slicing → girth circumferences
│   ├── garment/
│   │   ├── parse.py          # garment segmentation + panel extraction
│   │   └── warp.py           # TPS warp + Poisson compositing
│   ├── sizing/
│   │   ├── recommend.py      # explainable size recommendation engine
│   │   └── size_charts.csv   # Indian sizing charts (kurta M/F, saree blouse)
│   ├── export/
│   │   └── glb.py            # trimesh → .glb avatar export
│   └── utils/
│       ├── visualize.py      # landmark overlay, depth colourmap, bar chart
│       └── io.py             # image I/O, JSON helpers
├── tests/
│   ├── test_pose.py
│   ├── test_measure.py
│   └── test_sizing.py
├── docs/
│   └── architecture.md
├── samples/                  # test fixtures (not tracked by git)
├── notebooks/                # exploratory notebooks
├── requirements.txt
└── README.md
```

---

## Validation

Validated on 5 participants (tape measure ground truth):

| Measurement | Target | Result |
|---|---|---|
| Chest | ±3 cm | — |
| Waist | ±3 cm | — |
| Height | ±2 cm | — |
| Size accuracy | ≥80% | — |

*Results table will be filled after in-person validation (Week 3).*

---

## Garment support (v1)

| Type | Sizes | Notes |
|---|---|---|
| Men's kurta | XS–3XL | Chest / waist primary |
| Women's kurta / anarkali | XS–3XL | Chest / waist / hip |
| Saree blouse | 28–44 | Chest primary |

Lehenga, sherwani → post-v1.

---

## Roadmap

- [x] Pose + segmentation + depth pipeline
- [x] SMPL fitting (3-stage staged optimization)
- [x] Measurement extraction (mesh slicing + convex hull)
- [x] Size recommendation with cm reasoning
- [x] Garment parsing (panel extraction)
- [x] TPS warp + Poisson compositing
- [x] Streamlit 3-step wizard
- [x] .glb export
- [ ] Full TPS warp with SMPL surface control points
- [ ] Validation table (5 participants)
- [ ] HuggingFace Spaces deployment
- [ ] 90-second demo video

---

## Tech stack

`Python 3.10` · `PyTorch` · `MediaPipe` · `OpenCV` · `rembg` · `Depth Anything v2`
`smplx` · `trimesh` · `Open3D` · `Streamlit` · `scipy` · `pandas`

---

## Author

**Abbas S** — Final-year B.Tech CSE (AI/ML), SIMATS Engineering College, Chennai.
[GitHub](https://github.com/Abbas5055) · [Portfolio](https://abbas5055.github.io/abbas_s.github.io/) · [LinkedIn](https://linkedin.com/in/abbas0807kl)

---

## License

MIT
